#ifndef _MS_CMU_GET_H_
#define _MS_CMU_GET_H_

int handle_get_msg(unsigned short cmd_id, int skt, unsigned int cseq, char* buf, int len);

#endif/*_MS_CMU_GET_H_*/


