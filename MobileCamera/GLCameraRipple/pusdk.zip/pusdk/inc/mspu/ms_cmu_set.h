#ifndef _MS_CMU_SET_H_
#define _MS_CMU_SET_H_


int handle_set_msg(unsigned short cmd_id, int skt, unsigned int cseq, char* buf, int len);

#endif/*_MS_CMU_SET_H_*/


