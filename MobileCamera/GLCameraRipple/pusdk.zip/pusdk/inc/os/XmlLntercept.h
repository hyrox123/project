#ifndef XML_LNTER_CEPT_H_
#define XML_LNTER_CEPT_H_


char *XmlLntercept(char *SrcBuf) ;

char *Contrary_XmlLntercept(char *SrcBuf) ;

char *prase_oper_query_storage_pack_toDate(char *Srcbuf);

char *prase_oper_query_storage_pack_fromDate(char *Srcbuf);


#endif
