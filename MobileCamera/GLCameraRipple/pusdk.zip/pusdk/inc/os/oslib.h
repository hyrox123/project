/************************************************************
* AUTHOR:	
* CONTENT:	
* NOTE:	
* HISTORY:				
***********************************************************/

#ifndef __OSLIB_H__
#define __OSLIB_H__

#ifdef __cplusplus
extern "C"
{
#endif
/////////////////////////////////////////////////////////////////////


	#include "ossys.h"
	#include "osevent.h"
	#include "osmutex.h"
	#include "osqueue.h"
	#include "osthread.h"
	#include "osthreadpool.h"

	#include "ossocket.h"

	#include "help.h"
	#include "osqueue_g.h"

/////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
}
#endif

#endif
